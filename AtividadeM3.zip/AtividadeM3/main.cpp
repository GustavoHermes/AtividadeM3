#include <iostream>
#include <cstdio>
#include "raylib.h"
#include <cstdlib>
#include <ctime>
#include <string>
#include <fstream>
using namespace std;

#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3
#define CENTER 4

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 800
#define SPEED 250.0f
#define RADIUS 10.0f

#define typeSpeed 0
#define typeStrength 1

struct Bloco{
  Rectangle coord = {0, 0, 100, 50};
  int vida, ponto;
};

struct Bola{
  Vector2 posBall = {SCREEN_WIDTH/2.0f , 500};
  int lastPosX;
  int lastPosY;
  bool usada=0;
  float velocidade=1.0;
  int dano=100;
  float tamanho = RADIUS;
  int vida=3;
};

struct Item{
  Rectangle box={0, 0, 20, 20};
  bool usado=1;
  int tipo;
  bool speedActive=0;
  double speedTime=0;
  bool strengthActive=0;
  double strengthTime=0;
};

void CriarBloco(Bloco *block){
  int count=0;
  while(count<49){
    for(int i=1; i<8; i++){
      for(int j=1; j<8; j++){
      block[count].coord.x=i*100-50;
      block[count].coord.y=j*50;
      block[count].ponto = (rand()%4+1)*100;
      block[count].vida=block[count].ponto;
      count++;
      }
    }
  }
}

void DesenharBloco(Bloco *block){
  for(int i=0; i<49; i++){
    if(block[i].vida>0){
      switch (block[i].vida){
        case 100:{
          DrawRectangle(block[i].coord.x, block[i].coord.y, 100, 50, RED);
          break;
        }
        case 200:{
          DrawRectangle(block[i].coord.x, block[i].coord.y, 100, 50, BLUE);
          break;
        }
        case 300:{
          DrawRectangle(block[i].coord.x, block[i].coord.y, 100, 50, GREEN);
          break;
        }
        case 400:{
          DrawRectangle(block[i].coord.x, block[i].coord.y, 100, 50, PURPLE);
          break;
        }
      }
    }
  }
}

void CriarItem(Item &item, int x, int y){
  item.usado=0;
  item.box.x=x;
  item.box.y=y;
  item.tipo=rand()%2;
}

void MovimentarItem(Item &item, const float dt){
  item.box.y += (SPEED * dt)/2;
  if(item.box.y>SCREEN_HEIGHT-item.box.height){
    item.usado=1;
  }
}

void ItemEfeito(Item &item, Bola &ball){
  double tempo = GetTime();
  if(item.speedActive==1){
    ball.velocidade=2;
  }else if(ball.velocidade!=1){
    ball.velocidade=1;
  }
  if(item.strengthActive==1){
    ball.dano=200;
  }else if(ball.dano!=100){
    ball.dano=100;
  }
  if(tempo>item.speedTime){
    item.speedActive=0;
  }
  if(tempo>item.strengthTime){
    item.strengthActive=0;
  }
}

void ColetarItem(Item &item, Rectangle &player, Bola &ball){
  if(CheckCollisionRecs(item.box, player)){
    item.usado=1;
    double limite = GetTime()+10;
    switch (item.tipo){
      case typeSpeed:{
        item.speedActive=1;
        item.speedTime=limite;
        break;
      }
      case typeStrength:{
        item.strengthActive=1;
        item.strengthTime=limite;
      }
    }
  }
}

void DesenharItem(Item &item){
  if(item.usado==0){
    if(item.tipo==typeSpeed){
      DrawRectangle(item.box.x, item.box.y, item.box.width, item.box.height, BLUE);
    }
    if(item.tipo==typeStrength){
      DrawRectangle(item.box.x, item.box.y, item.box.width, item.box.height, RED);
    }
  }
}

void Lancar(Bola &ball, Rectangle &player){
  if(ball.usada==0){
    ball.posBall.x=player.x+50;
    ball.posBall.y=player.y-20;
  }
  if(IsMouseButtonPressed(0)){
    ball.usada=1;
    ball.lastPosX=CENTER;
    ball.lastPosY=UP;
  }
}

void Colisao(Bola &ball, Rectangle &player, Bloco *block, Item &item, int &score){
  Rectangle ballBox = {ball.posBall.x-10, ball.posBall.y-10, RADIUS*2, RADIUS*2};
  for(int i=0; i<49; i++){
    if(block[i].vida>0){
      if(CheckCollisionRecs(ballBox, block[i].coord)){
        if(ball.posBall.x<(block[i].coord.x+block[i].coord.width/2)&&ball.lastPosX!=LEFT){
          ball.lastPosX=LEFT;
        }
        if(ball.posBall.x>(block[i].coord.x+block[i].coord.width/2)&&ball.lastPosX!=RIGHT){
          ball.lastPosX=RIGHT;
        }
        if(ball.posBall.y<(block[i].coord.y+block[i].coord.height/2)&&ball.lastPosY!=UP){
          ball.lastPosY=UP;
        }
        if(ball.posBall.y>(block[i].coord.y+block[i].coord.height/2)&&ball.lastPosY!=RIGHT){
          ball.lastPosY=DOWN;
        }
        if(block[i].ponto==400&&(block[i].vida-ball.dano)<=0&&item.usado==1){
          CriarItem(item, block[i].coord.x+50, block[i].coord.y+20);
        }
        if((block[i].vida-ball.dano)<=0){
          score+=block[i].ponto;
        }
        block[i].vida -= ball.dano;
      }
    }
  }
  if(ball.posBall.x < RADIUS){
    ball.posBall.x=RADIUS;
    ball.lastPosX=RIGHT;
  }
  if(ball.posBall.x > SCREEN_WIDTH-RADIUS){
    ball.posBall.x=SCREEN_WIDTH-RADIUS;
    ball.lastPosX=LEFT;
  }
  if(ball.posBall.y < RADIUS){
    ball.posBall.y=RADIUS;
    ball.lastPosY=DOWN;
  }
  if(ball.posBall.y > SCREEN_HEIGHT-RADIUS){
    ball.vida--;
    ball.usada=0;
    Lancar(ball, player);
  }
  if(CheckCollisionCircleRec(ball.posBall, ball.tamanho, player)){
    if(ball.posBall.x<(player.x+player.width/2)&&ball.lastPosX!=LEFT){
      ball.lastPosX=LEFT;
    }
    if(ball.posBall.x>(player.x+player.width/2)&&ball.lastPosX!=RIGHT){
      ball.lastPosX=RIGHT;
    }
    if(ball.posBall.y<(player.y+player.height/2)&&ball.lastPosY!=UP){
      ball.lastPosY=UP;
    }
    if(ball.posBall.y>(player.y+player.height/2)&&ball.lastPosY!=DOWN){
      ball.lastPosY=DOWN;
    }
  }
}

void MovimentacaoBola(Bola &ball, const float dt){
  if(ball.usada!=0){
    if(ball.lastPosY==UP){
        ball.posBall.y -= (SPEED * dt)*ball.velocidade;
    }else if(ball.lastPosY==DOWN){
        ball.posBall.y += (SPEED * dt)*ball.velocidade;
    }
    if(ball.lastPosX==LEFT){
        ball.posBall.x -= (SPEED * dt)*ball.velocidade;
    }else if(ball.lastPosX==RIGHT){
        ball.posBall.x += (SPEED * dt)*ball.velocidade;
    }
  }
}

void DesenharVida(Bola &ball){
  for(int i=0; i<ball.vida; i++){
    DrawCircle(((SCREEN_WIDTH/2)-30.0f)+(i*30), 30, RADIUS, GRAY);
  }
}

void SelecionarNome(string &playerName, int nameLength){
  char letter = GetCharPressed();
  if(letter!=0&&(playerName.length()<=nameLength)){
    playerName = playerName+letter;
  }
}

void SalvarScore(string &playerName, int score){
  fstream Ranking("ranking.txt");
  Ranking.seekg(fstream::beg);
  for(int i=0; i<10; i++){
    string check;
    getline(Ranking, check, ';');
  }
}

int main(){
  int state=3;
  int difficulty = 0;
  int score = 0;
  srand(time(0));
  InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Arkanoid");
  SetTargetFPS(60);


  Texture2D titulo = LoadTexture("Textures//Titulo.png");
  Texture2D jogar = LoadTexture("Textures//Botao_Jogar.png");
  Texture2D sair = LoadTexture("Textures//Botao_Sair.png");
  Texture2D rank = LoadTexture("Textures//Botao_Rank.png");
  Rectangle jogarRec = {SCREEN_WIDTH/2, 500, 400, 100};
  Vector2 jogarPos = {SCREEN_WIDTH/2-200, 450};
  Rectangle rankRec = {SCREEN_WIDTH/2, 600, 400, 100};
  Vector2 rankPos = {SCREEN_WIDTH/2-200, 550};
  Rectangle sairRec = {SCREEN_WIDTH/2, 700, 400, 100};
  Vector2 sairPos = {SCREEN_WIDTH/2-200, 650};
  while(!WindowShouldClose()){
    while(state==0){
      BeginDrawing();
      ClearBackground(BLACK);
      DrawTexture(titulo, SCREEN_WIDTH/2-625/2, 100, WHITE);
      if((GetMouseX()>=(jogarRec.x-jogarRec.width/2)&&GetMouseX()<=(jogarRec.x+jogarRec.width/2))&&((GetMouseY()>=(jogarRec.y-jogarRec.height/2))&&(GetMouseY()<=(jogarRec.y+jogarRec.height/2)))){
        DrawTextureRec(jogar, jogarRec, jogarPos, RED);
        if(IsMouseButtonPressed(0)){
          score=0;
          state=1;
        }
      }else{
        DrawTextureRec(jogar, jogarRec, jogarPos, WHITE);
      }
      if((GetMouseX()>=(rankRec.x-rankRec.width/2)&&GetMouseX()<=(rankRec.x+rankRec.width/2))&&((GetMouseY()>=(rankRec.y-rankRec.height/2))&&(GetMouseY()<=(rankRec.y+rankRec.height/2)))){
        DrawTextureRec(rank, rankRec, rankPos, RED);
        if(IsMouseButtonPressed(0)){
          state=2;
        }
      }else{
        DrawTextureRec(rank, rankRec, rankPos, WHITE);
      }
      if((GetMouseX()>=(sairRec.x-sairRec.width/2)&&GetMouseX()<=(sairRec.x+sairRec.width/2))&&((GetMouseY()>=(sairRec.y-sairRec.height/2))&&(GetMouseY()<=(sairRec.y+sairRec.height/2)))){
        DrawTextureRec(sair, sairRec, sairPos, RED);
        if(IsMouseButtonPressed(0)){
          state=4;
        }
      }else{
        DrawTextureRec(sair, sairRec, sairPos, WHITE);
      }
      EndDrawing();
    }

    Bola ball;
    Rectangle player = {SCREEN_WIDTH/2.0f-50.0f, 600.0f, 100, 30};
    Bloco block[49];
    CriarBloco(block);
    Item item;
    while(state==1){
    float dt = GetFrameTime();
    player.x=GetMouseX()-50.0f;
    if(player.x<=0){
      player.x=0;
    }
    if(player.x>=SCREEN_WIDTH-100){
      player.x=SCREEN_WIDTH-100;
    }
    if(IsKeyDown(KEY_C)){
      ball.velocidade=2;
    }
    if(IsKeyDown(KEY_V)){
      ball.velocidade=1;
    }
    if(IsKeyDown(KEY_B)){
      ball.velocidade=0.5;
    }
    MovimentarItem(item, dt);
    Lancar(ball, player);
    ColetarItem(item, player, ball);
    MovimentacaoBola(ball, dt);
    Colisao(ball, player, block, item, score);
    ItemEfeito(item, ball);
    BeginDrawing();
    ClearBackground(BLACK);
    DesenharVida(ball);
    if(item.speedActive==1){
      DrawRectangle(SCREEN_WIDTH-30, SCREEN_HEIGHT-30, 20, 20, BLUE);
    }
    if(item.strengthActive==1){
      DrawRectangle(SCREEN_WIDTH-60, SCREEN_HEIGHT-30, 20, 20, RED);
    }
    DrawCircle(ball.posBall.x, ball.posBall.y, ball.tamanho, WHITE);
    DrawRectangle(player.x, player.y, 100, 30, RED);
    DesenharBloco(block);
    DesenharItem(item);
    DrawFPS(90, SCREEN_HEIGHT-50);
    if(ball.vida<=0){
      state=3;
    }
    EndDrawing();
    }
    while(state==2){

    }
    string scoreText="SCORE: " + to_string(score);
    string playerName="Insira Nome: ";
    int nameLength=playerName.length()+5;
    while(state==3){
      BeginDrawing();
      ClearBackground(BLACK);
      DrawText("GAME OVER", SCREEN_WIDTH/2-300, 300, 100, RED);
      DrawText(scoreText.c_str(), SCREEN_WIDTH/2-100, 400, 50, BLUE);
      SelecionarNome(playerName, nameLength);
      DrawText(playerName.c_str(), 200, 500, 40, BLUE);
      if(IsKeyDown(KEY_SPACE)||IsKeyDown(KEY_ENTER)){
        state=0;
      }
      EndDrawing();
    }
    while(state==4){
      CloseWindow();
      return 0;
    }
  }
CloseWindow();
return 0;
}