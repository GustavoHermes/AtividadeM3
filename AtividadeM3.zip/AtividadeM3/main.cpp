#include <iostream>
#include "raylib.h"
#include <cstdlib>
#include <ctime>
using namespace std;

#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 800
#define SPEED 250.0f
#define RADIUS 10.0f

struct Bloco{
  int x, y;
  int ponto;
  bool alive=1;
};

void Colisao(Vector2 &pos, int &lastPosY, int&lastPosX, Rectangle player){
  if(pos.x < RADIUS){
    pos.x=RADIUS;
    lastPosX=RIGHT;
  }
  if(pos.x > SCREEN_WIDTH-RADIUS){
    pos.x=SCREEN_WIDTH-RADIUS;
    lastPosX=LEFT;
  }
  if(pos.y < RADIUS){
    pos.y=RADIUS;
    lastPosY=DOWN;
  }
  if(pos.y > SCREEN_HEIGHT-RADIUS){
    pos.y=SCREEN_HEIGHT-RADIUS;
    lastPosY=UP;
  }
  if(CheckCollisionCircleRec(pos, RADIUS, player)){
    if(lastPosY==UP){
        lastPosY=DOWN;
    }
    if(lastPosY==DOWN){
        lastPosY=UP;
    }
  }
}

void MovimentacaoBola(Vector2 &pos, const int lastPosY, const int lastPosX, const float dt){
  /*switch(lastPos){
    case UP:{
      pos.y -= SPEED * dt;
      break;
    }
    case DOWN:{
      pos.y += SPEED * dt;
      break;
    }
    case LEFT:{
      pos.x -= SPEED * dt;
      break;
    }
    case RIGHT:{
      pos.x += SPEED * dt;
      break;
    }
  }*/
 if(lastPosY==UP){
    pos.y -= SPEED * dt;
 }
 if(lastPosY==DOWN){
    pos.y += SPEED * dt;
 }
 if(lastPosX==LEFT){
    pos.x -= SPEED * dt;
 }
 if(lastPosX==RIGHT){
    pos.x += SPEED * dt;
 }
}

void CriarBloco(Bloco *block){
  int count=0;
  while(count<30){
    for(int i=1; i<6; i++){
      for(int j=2; j<8; j++){
      block[count].x=i*100+50;
      block[count].y=j*50;
      block[count].ponto = (rand()%4+1)*100;
      count++;
      }
    }
  }
}

void DesenharBloco(Bloco *block){
  for(int i=0; i<30; i++){
    switch (block[i].ponto)
    {
    case 100:{
      DrawRectangle(block[i].x, block[i].y, 100, 50, RED);
      break;
    }
    case 200:{
      DrawRectangle(block[i].x, block[i].y, 100, 50, BLUE);
      break;
    }
    case 300:{
      DrawRectangle(block[i].x, block[i].y, 100, 50, GREEN);
      break;
    }
    case 400:{
      DrawRectangle(block[i].x, block[i].y, 100, 50, PURPLE);
      break;
    }
    }
  }
}

int main(){
  srand(time(0));
  InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Arkanoid");
  SetTargetFPS(60);

  Vector2 posBall = {SCREEN_WIDTH/2.0f , SCREEN_HEIGHT/2.0f};
  int lastPosY = DOWN;
  int lastPosX = RIGHT;
  Rectangle player = {SCREEN_WIDTH/2.0f-50.0f, 600.0f, 100, 30};
  Bloco block[30];
  CriarBloco(block);

  while(!WindowShouldClose()){
  float dt = GetFrameTime();

  /*if(IsKeyDown(KEY_LEFT)||IsKeyDown(KEY_A)){
    player.x -= SPEED * dt;
  }
  if(IsKeyDown(KEY_RIGHT)||IsKeyDown(KEY_D)){
    player.x += SPEED * dt;
  }
  */
  player.x=GetMouseX()-50.0f;
  if(player.x<=0){
    player.x=0;
  }
  if(player.x>=SCREEN_WIDTH-100){
    player.x=SCREEN_WIDTH-100;
  }
  MovimentacaoBola(posBall, lastPosY, lastPosX, dt);
  Colisao(posBall, lastPosY, lastPosX, player);
  BeginDrawing();
  ClearBackground(BLACK);
  DrawCircle(posBall.x, posBall.y, RADIUS, WHITE);
  DrawRectangle(player.x, player.y, 100, 30, RED);
  DesenharBloco(block);
  DrawFPS(SCREEN_WIDTH - 90, 10);
  EndDrawing();
  }
CloseWindow();
return 0;
}